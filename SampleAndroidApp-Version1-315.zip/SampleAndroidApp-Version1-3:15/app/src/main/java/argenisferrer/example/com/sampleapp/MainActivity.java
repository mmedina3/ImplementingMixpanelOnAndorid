package argenisferrer.example.com.sampleapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import com.mixpanel.android.mpmetrics.MixpanelAPI;
import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {

    public static final String mpToken = "4d93469f0101a1e34f888249aae2fd16";
    private MixpanelAPI mixpanel;
    private Context mContext;
    private JSONObject mCurrentProps;

    private Button mMainButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;
        mixpanel = MixpanelAPI.getInstance(mContext, mpToken);
        mixpanel.track("App Launched");

        mMainButton = (Button) findViewById(R.id.btnMain);

        mMainButton.setOnClickListener((v) -> {
            boolean loggedIn = false;
            mCurrentProps = mixpanel.getSuperProperties();
            try {
                if (mCurrentProps.has("loggedIn") && mCurrentProps.getBoolean("loggedIn")) {
                    loggedIn = true;
                } else {
                    mCurrentProps.put("loggedIn", loggedIn);
                }
                mixpanel.registerSuperProperties(mCurrentProps);
            } catch (JSONException e) {
            }
            Intent intent;
            if (loggedIn) {
                intent = new Intent(mContext, StickerActivity.class);
                Sticker mSticker = new Sticker(true);
                intent.putExtra("StickerId", mSticker.getSticketId());
            } else {
                intent = new Intent(mContext, Auth.class);
                mixpanel.track("Auth Started");
            }
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        //every time the app comes into the background
        mixpanel.track("app is in the foreground");
        mixpanel.flush();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //app going into background
        mixpanel.track("app is in the background");
    }

    @Override
    protected void onDestroy() {
        mixpanel.flush();
        super.onDestroy();
    }
}

