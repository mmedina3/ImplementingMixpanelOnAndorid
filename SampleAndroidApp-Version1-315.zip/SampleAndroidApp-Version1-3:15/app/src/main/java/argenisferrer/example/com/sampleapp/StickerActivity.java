package argenisferrer.example.com.sampleapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import com.mixpanel.android.mpmetrics.MixpanelAPI;

public class StickerActivity extends AppCompatActivity {

    ImageView mImageView;
    MixpanelAPI mixpanel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sticker);
        mixpanel = MixpanelAPI.getInstance(this, MainActivity.mpToken);

        Intent myIntent = getIntent();

        if(myIntent.getBooleanExtra("justSignedUp", false)){
            mixpanel.identify(myIntent.getStringExtra("email"));
            mixpanel.getPeople().set("$email", myIntent.getStringExtra("email"));
            mixpanel.getPeople().set("$name", myIntent.getStringExtra("name"));
            mixpanel.getPeople().set("$created", myIntent.getStringExtra("created"));
            mixpanel.track("Signed Up");
        }

        ImageView mainImageView = (ImageView) findViewById(R.id.mainImageView);
        mainImageView.setBackgroundResource(myIntent.getIntExtra("Sticker Id", R.mipmap.java));

        mixpanel.track("Sticker Viewed");

        Button btnShare = (Button) findViewById(R.id.btnShare);
        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mixpanel.track("Sticker Shared");
            }
        });

    }
}
