package com.example.trainingapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.mixpanel.android.mpmetrics.MixpanelAPI;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private String mpToken = "4d93469f0101a1e34f888249aae2fd16";
    MixpanelAPI mixpanel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mixpanel = MixpanelAPI.getInstance(this, mpToken);

        JSONObject props = new JSONObject();
        try {
            props.put("$email", "michelle@mixpanel.com");
            props.put("$first_name", "Michelle");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        mixpanel.registerSuperProperties(props);
        mixpanel.track("app loaded in memory");
        mixpanel.getPeople().set(props);
        mixpanel.getPeople().set("MP Staff", true);
        mixpanel.getPeople().identify(mixpanel.getDistinctId());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Every time the app comes into the background
        mixpanel.track("app is in the foreground");
        mixpanel.flush();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // app going into background
        mixpanel.track("app is in the background");
    }
}
